//
//  main.m
//  Animation
//
//  Created by Cast Group on 05/01/18.
//  Copyright © 2018 castgroup. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
