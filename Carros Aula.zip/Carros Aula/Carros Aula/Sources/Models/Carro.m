//
//  Carro.m
//  Carros Aula
//
//  Created by C1284047 (Edi Vergis) on 27/12/2017.
//  Copyright © 2017 Cast Group. All rights reserved.
//

#import "Carro.h"

@implementation Carro

@end

@implementation Carros

@end

@implementation RootCarro

@end
