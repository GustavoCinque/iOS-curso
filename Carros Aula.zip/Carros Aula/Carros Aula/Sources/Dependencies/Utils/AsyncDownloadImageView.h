//
//  AsyncDownloadImageView.h
//  Carros Aula
//
//  Created by Cast Group on 04/01/18.
//  Copyright © 2018 Cast Group. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AsyncDownloadImageView : UIImageView

@property(nonatomic, copy) NSString* urlFoto;

@end
