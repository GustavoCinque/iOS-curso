//
//  NSString+Utils.h
//  Carros Aula
//
//  Created by C1284047 (Edi Vergis) on 29/12/2017.
//  Copyright © 2017 Cast Group. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Utils)

- (NSString*)clearCharsets;

@end
